# Tesi Pollini Gabriel Bizzo
 Tesi di laurea del corso accademico di I livello in Musica Elettronica di Gabriel Bizzo, Conservatorio Pollini di Padova, anno accademico 2020-2021 
